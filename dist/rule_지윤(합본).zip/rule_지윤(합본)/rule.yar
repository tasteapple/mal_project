rule Detect_System_Manipulation_Binary {
    meta
        description = Detects test.exe based on PE structure and specific API imports
        author = Gemini Security Analyst
        date = 2026-04-02

    strings
         PE 헤더 확인용 (MZ)
        $mz = { 4D 5A }
        
         주요 API 함수 문자열
        $api1 = RegSetValueExA ascii
        $api2 = VirtualProtect ascii
        $api3 = VirtualQuery ascii
        
         C++ 런타임 및 라이브러리 특징
        $cpp1 = basic_string ascii
        $cpp2 = char_traits ascii
        $runtime = mingw_initltsdyn ascii

    condition
         MZ 헤더로 시작하고, 주요 API 및 C++ 특징이 모두 발견될 때
        $mz at 0 and (all of ($api)) and (any of ($cpp, $runtime))
}