rule PS_MultiAction_Recon_Staging_Persistence_DefenseEvasion
{
    meta:
        description = "Detects PowerShell scripts combining recon, document staging, scheduled task persistence, AV enumeration, and firewall disable"
        author = "OpenAI"
        date = "2026-04-02"
        version = "1.0"
        target = "PowerShell script text"
        confidence = "medium-high"

    strings:
        $ps1 = "powershell" ascii nocase
        $ps2 = "Out-File" ascii nocase

        $net1 = "Test-NetConnection" ascii nocase
        $net2 = "-Port 445" ascii nocase
        $net3 = "TcpTestSucceeded" ascii nocase
        $net4 = "192.168." ascii nocase

        $doc1 = "$env:USERPROFILE\\Documents" ascii nocase
        $doc2 = "*.pdf" ascii nocase
        $doc3 = "*.docx" ascii nocase
        $doc4 = "*.txt" ascii nocase
        $doc5 = "Get-ChildItem" ascii nocase
        $doc6 = "Copy-Item" ascii nocase
        $doc7 = "Staging" ascii nocase
        $doc8 = "-Recurse" ascii nocase

        $task1 = "New-ScheduledTaskAction" ascii nocase
        $task2 = "New-ScheduledTaskTrigger" ascii nocase
        $task3 = "Register-ScheduledTask" ascii nocase
        $task4 = "-User \"SYSTEM\"" ascii nocase
        $task5 = "WindowsSecurityCheck" ascii nocase

        $av1 = "Get-CimInstance" ascii nocase
        $av2 = "root/SecurityCenter2" ascii nocase
        $av3 = "AntiVirusProduct" ascii nocase
        $av4 = "productState" ascii nocase

        $fw1 = "Set-NetFirewallProfile" ascii nocase
        $fw2 = "-Enabled False" ascii nocase
        $fw3 = "Domain,Public,Private" ascii nocase

    condition:
        filesize < 200KB and
        (
            (2 of ($net*)) and
            (4 of ($doc*)) and
            (2 of ($task*)) and
            (2 of ($av*)) and
            (2 of ($fw*))
        )
}